``QRegExpValidator``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegExpValidator
   :members:
   :undoc-members:
   :show-inheritance:
