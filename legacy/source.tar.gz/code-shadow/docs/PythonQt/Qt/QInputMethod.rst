``QInputMethod``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QInputMethod
   :members:
   :undoc-members:
   :show-inheritance:
