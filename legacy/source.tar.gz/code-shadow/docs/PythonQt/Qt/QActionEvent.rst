``QActionEvent``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QActionEvent
   :members:
   :undoc-members:
   :show-inheritance:
