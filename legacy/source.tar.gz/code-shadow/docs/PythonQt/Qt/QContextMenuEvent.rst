``QContextMenuEvent``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QContextMenuEvent
   :members:
   :undoc-members:
   :show-inheritance:
