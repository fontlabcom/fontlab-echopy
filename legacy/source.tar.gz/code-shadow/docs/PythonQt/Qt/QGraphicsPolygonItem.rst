``QGraphicsPolygonItem``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsPolygonItem
   :members:
   :undoc-members:
   :show-inheritance:
