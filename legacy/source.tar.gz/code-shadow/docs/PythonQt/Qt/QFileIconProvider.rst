``QFileIconProvider``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileIconProvider
   :members:
   :undoc-members:
   :show-inheritance:
