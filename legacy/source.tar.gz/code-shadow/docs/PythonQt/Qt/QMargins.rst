``QMargins``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMargins
   :members:
   :undoc-members:
   :show-inheritance:
