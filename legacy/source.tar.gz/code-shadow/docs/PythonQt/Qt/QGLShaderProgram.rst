``QGLShaderProgram``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLShaderProgram
   :members:
   :undoc-members:
   :show-inheritance:
