``QCheckBox``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCheckBox
   :members:
   :undoc-members:
   :show-inheritance:
