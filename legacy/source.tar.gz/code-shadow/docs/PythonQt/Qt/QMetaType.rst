``QMetaType``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMetaType
   :members:
   :undoc-members:
   :show-inheritance:
