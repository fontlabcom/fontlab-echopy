``QPolygonF``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPolygonF
   :members:
   :undoc-members:
   :show-inheritance:
