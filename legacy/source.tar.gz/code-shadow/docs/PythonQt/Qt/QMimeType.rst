``QMimeType``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMimeType
   :members:
   :undoc-members:
   :show-inheritance:
