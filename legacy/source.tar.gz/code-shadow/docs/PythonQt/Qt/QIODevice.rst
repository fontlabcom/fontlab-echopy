``QIODevice``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QIODevice
   :members:
   :undoc-members:
   :show-inheritance:
