``QPauseAnimation``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPauseAnimation
   :members:
   :undoc-members:
   :show-inheritance:
