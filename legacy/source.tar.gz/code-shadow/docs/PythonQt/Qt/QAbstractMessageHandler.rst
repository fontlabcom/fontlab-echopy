``QAbstractMessageHandler``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractMessageHandler
   :members:
   :undoc-members:
   :show-inheritance:
