``QFrame``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFrame
   :members:
   :undoc-members:
   :show-inheritance:
