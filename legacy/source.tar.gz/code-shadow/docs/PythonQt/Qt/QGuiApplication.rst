``QGuiApplication``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGuiApplication
   :members:
   :undoc-members:
   :show-inheritance:
