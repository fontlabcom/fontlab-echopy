``QInputDialog``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QInputDialog
   :members:
   :undoc-members:
   :show-inheritance:
