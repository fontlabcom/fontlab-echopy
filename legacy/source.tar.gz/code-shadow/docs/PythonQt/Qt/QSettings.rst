``QSettings``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSettings
   :members:
   :undoc-members:
   :show-inheritance:
