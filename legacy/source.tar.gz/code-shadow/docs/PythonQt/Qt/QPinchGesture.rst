``QPinchGesture``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPinchGesture
   :members:
   :undoc-members:
   :show-inheritance:
