``QApplication``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QApplication
   :members:
   :undoc-members:
   :show-inheritance:
