``QHistoryState``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QHistoryState
   :members:
   :undoc-members:
   :show-inheritance:
