``QFontDatabase``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFontDatabase
   :members:
   :undoc-members:
   :show-inheritance:
