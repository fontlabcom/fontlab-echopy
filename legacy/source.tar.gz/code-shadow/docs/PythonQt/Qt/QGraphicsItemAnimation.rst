``QGraphicsItemAnimation``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsItemAnimation
   :members:
   :undoc-members:
   :show-inheritance:
