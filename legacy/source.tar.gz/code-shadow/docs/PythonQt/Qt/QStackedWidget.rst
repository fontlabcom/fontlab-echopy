``QStackedWidget``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStackedWidget
   :members:
   :undoc-members:
   :show-inheritance:
