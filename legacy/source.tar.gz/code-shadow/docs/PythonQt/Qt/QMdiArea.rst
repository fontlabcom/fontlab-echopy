``QMdiArea``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMdiArea
   :members:
   :undoc-members:
   :show-inheritance:
