``QAbstractItemView``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractItemView
   :members:
   :undoc-members:
   :show-inheritance:
