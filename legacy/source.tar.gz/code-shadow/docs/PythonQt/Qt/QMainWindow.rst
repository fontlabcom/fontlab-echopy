``QMainWindow``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMainWindow
   :members:
   :undoc-members:
   :show-inheritance:
