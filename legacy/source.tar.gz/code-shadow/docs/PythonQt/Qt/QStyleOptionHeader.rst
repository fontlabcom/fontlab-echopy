``QStyleOptionHeader``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionHeader
   :members:
   :undoc-members:
   :show-inheritance:
