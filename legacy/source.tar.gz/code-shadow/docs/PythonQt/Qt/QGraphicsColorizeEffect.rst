``QGraphicsColorizeEffect``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsColorizeEffect
   :members:
   :undoc-members:
   :show-inheritance:
