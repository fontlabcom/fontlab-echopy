``QKeySequence``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QKeySequence
   :members:
   :undoc-members:
   :show-inheritance:
