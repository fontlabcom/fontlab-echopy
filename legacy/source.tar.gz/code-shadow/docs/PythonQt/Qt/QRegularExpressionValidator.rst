``QRegularExpressionValidator``
===============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegularExpressionValidator
   :members:
   :undoc-members:
   :show-inheritance:
