``QPixmapCache``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPixmapCache
   :members:
   :undoc-members:
   :show-inheritance:
