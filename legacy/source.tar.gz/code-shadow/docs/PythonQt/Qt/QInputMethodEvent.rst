``QInputMethodEvent``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QInputMethodEvent
   :members:
   :undoc-members:
   :show-inheritance:
