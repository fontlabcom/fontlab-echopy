``QStandardPaths``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStandardPaths
   :members:
   :undoc-members:
   :show-inheritance:
