``QStandardItem``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStandardItem
   :members:
   :undoc-members:
   :show-inheritance:
