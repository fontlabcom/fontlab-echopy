``QFileSelector``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileSelector
   :members:
   :undoc-members:
   :show-inheritance:
