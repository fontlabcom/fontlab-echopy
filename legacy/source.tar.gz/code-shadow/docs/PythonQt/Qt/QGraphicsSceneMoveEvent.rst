``QGraphicsSceneMoveEvent``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneMoveEvent
   :members:
   :undoc-members:
   :show-inheritance:
