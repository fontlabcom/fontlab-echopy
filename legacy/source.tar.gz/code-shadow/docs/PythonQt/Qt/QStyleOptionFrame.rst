``QStyleOptionFrame``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionFrame
   :members:
   :undoc-members:
   :show-inheritance:
