``QAbstractState``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractState
   :members:
   :undoc-members:
   :show-inheritance:
