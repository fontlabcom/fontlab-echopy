``QIconDragEvent``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QIconDragEvent
   :members:
   :undoc-members:
   :show-inheritance:
