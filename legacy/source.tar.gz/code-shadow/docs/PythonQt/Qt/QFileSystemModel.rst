``QFileSystemModel``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileSystemModel
   :members:
   :undoc-members:
   :show-inheritance:
