``QSequentialAnimationGroup``
=============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSequentialAnimationGroup
   :members:
   :undoc-members:
   :show-inheritance:
