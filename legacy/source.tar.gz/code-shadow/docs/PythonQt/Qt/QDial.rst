``QDial``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDial
   :members:
   :undoc-members:
   :show-inheritance:
