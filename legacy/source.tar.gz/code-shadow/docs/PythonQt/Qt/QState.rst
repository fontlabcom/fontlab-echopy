``QState``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QState
   :members:
   :undoc-members:
   :show-inheritance:
