``QCoreApplication``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCoreApplication
   :members:
   :undoc-members:
   :show-inheritance:
