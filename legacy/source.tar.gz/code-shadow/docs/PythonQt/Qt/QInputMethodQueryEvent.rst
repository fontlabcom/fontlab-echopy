``QInputMethodQueryEvent``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QInputMethodQueryEvent
   :members:
   :undoc-members:
   :show-inheritance:
