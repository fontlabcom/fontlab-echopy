``QLabel``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLabel
   :members:
   :undoc-members:
   :show-inheritance:
