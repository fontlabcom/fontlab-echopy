``QDataWidgetMapper``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDataWidgetMapper
   :members:
   :undoc-members:
   :show-inheritance:
