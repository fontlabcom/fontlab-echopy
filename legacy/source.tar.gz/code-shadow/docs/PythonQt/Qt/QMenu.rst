``QMenu``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMenu
   :members:
   :undoc-members:
   :show-inheritance:
