``PaintContext``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: PaintContext
   :members:
   :undoc-members:
   :show-inheritance:
