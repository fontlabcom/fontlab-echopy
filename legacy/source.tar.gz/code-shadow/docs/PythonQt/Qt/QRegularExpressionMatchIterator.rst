``QRegularExpressionMatchIterator``
===================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegularExpressionMatchIterator
   :members:
   :undoc-members:
   :show-inheritance:
