``QStyleOptionFocusRect``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionFocusRect
   :members:
   :undoc-members:
   :show-inheritance:
