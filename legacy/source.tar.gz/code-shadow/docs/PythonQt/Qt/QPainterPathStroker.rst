``QPainterPathStroker``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPainterPathStroker
   :members:
   :undoc-members:
   :show-inheritance:
