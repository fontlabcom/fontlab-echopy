``QGraphicsView``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsView
   :members:
   :undoc-members:
   :show-inheritance:
