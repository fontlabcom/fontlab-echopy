``QAbstractItemDelegate``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractItemDelegate
   :members:
   :undoc-members:
   :show-inheritance:
