``QGLFramebufferObject``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLFramebufferObject
   :members:
   :undoc-members:
   :show-inheritance:
