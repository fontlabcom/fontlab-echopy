``QOpenGLTimeMonitor``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLTimeMonitor
   :members:
   :undoc-members:
   :show-inheritance:
