``QLineF``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLineF
   :members:
   :undoc-members:
   :show-inheritance:
