``QStyleOptionDockWidget``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionDockWidget
   :members:
   :undoc-members:
   :show-inheritance:
