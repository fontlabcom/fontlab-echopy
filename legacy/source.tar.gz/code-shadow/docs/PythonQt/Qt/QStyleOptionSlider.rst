``QStyleOptionSlider``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionSlider
   :members:
   :undoc-members:
   :show-inheritance:
