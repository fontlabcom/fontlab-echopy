``QStyleOptionToolButton``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionToolButton
   :members:
   :undoc-members:
   :show-inheritance:
