``QStyleOptionMenuItem``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionMenuItem
   :members:
   :undoc-members:
   :show-inheritance:
