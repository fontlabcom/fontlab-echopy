``QGraphicsSceneResizeEvent``
=============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneResizeEvent
   :members:
   :undoc-members:
   :show-inheritance:
