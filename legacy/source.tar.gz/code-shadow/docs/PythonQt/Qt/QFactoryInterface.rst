``QFactoryInterface``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFactoryInterface
   :members:
   :undoc-members:
   :show-inheritance:
