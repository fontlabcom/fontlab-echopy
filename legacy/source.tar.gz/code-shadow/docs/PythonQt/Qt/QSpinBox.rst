``QSpinBox``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSpinBox
   :members:
   :undoc-members:
   :show-inheritance:
