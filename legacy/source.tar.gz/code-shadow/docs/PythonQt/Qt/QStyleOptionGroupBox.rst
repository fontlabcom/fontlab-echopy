``QStyleOptionGroupBox``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionGroupBox
   :members:
   :undoc-members:
   :show-inheritance:
