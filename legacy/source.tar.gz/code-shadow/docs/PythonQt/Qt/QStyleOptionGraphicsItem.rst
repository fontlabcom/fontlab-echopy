``QStyleOptionGraphicsItem``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionGraphicsItem
   :members:
   :undoc-members:
   :show-inheritance:
