``QTableWidgetItem``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QTableWidgetItem
   :members:
   :undoc-members:
   :show-inheritance:
