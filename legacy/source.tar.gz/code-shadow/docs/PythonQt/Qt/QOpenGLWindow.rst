``QOpenGLWindow``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLWindow
   :members:
   :undoc-members:
   :show-inheritance:
