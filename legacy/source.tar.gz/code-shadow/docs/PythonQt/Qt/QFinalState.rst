``QFinalState``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFinalState
   :members:
   :undoc-members:
   :show-inheritance:
