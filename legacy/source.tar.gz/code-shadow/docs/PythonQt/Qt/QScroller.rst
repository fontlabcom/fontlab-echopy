``QScroller``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QScroller
   :members:
   :undoc-members:
   :show-inheritance:
