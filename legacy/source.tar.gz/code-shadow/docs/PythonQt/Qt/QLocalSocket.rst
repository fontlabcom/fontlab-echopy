``QLocalSocket``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLocalSocket
   :members:
   :undoc-members:
   :show-inheritance:
