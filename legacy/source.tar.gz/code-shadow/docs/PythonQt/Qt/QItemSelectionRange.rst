``QItemSelectionRange``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QItemSelectionRange
   :members:
   :undoc-members:
   :show-inheritance:
