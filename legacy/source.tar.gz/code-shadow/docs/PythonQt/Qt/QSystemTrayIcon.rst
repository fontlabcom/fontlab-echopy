``QSystemTrayIcon``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSystemTrayIcon
   :members:
   :undoc-members:
   :show-inheritance:
