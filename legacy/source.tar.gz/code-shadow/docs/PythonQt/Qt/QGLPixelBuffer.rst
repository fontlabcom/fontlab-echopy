``QGLPixelBuffer``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLPixelBuffer
   :members:
   :undoc-members:
   :show-inheritance:
