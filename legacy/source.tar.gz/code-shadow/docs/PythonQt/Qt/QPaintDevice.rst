``QPaintDevice``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPaintDevice
   :members:
   :undoc-members:
   :show-inheritance:
