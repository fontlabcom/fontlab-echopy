``QPolygon``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPolygon
   :members:
   :undoc-members:
   :show-inheritance:
