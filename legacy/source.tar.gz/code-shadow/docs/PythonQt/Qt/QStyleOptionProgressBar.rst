``QStyleOptionProgressBar``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionProgressBar
   :members:
   :undoc-members:
   :show-inheritance:
