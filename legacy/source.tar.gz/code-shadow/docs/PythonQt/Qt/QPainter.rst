``QPainter``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPainter
   :members:
   :undoc-members:
   :show-inheritance:
