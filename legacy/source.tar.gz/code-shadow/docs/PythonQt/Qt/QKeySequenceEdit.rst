``QKeySequenceEdit``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QKeySequenceEdit
   :members:
   :undoc-members:
   :show-inheritance:
