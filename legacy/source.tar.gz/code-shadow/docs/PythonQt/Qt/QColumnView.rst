``QColumnView``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QColumnView
   :members:
   :undoc-members:
   :show-inheritance:
