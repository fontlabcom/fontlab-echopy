``QQuaternion``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QQuaternion
   :members:
   :undoc-members:
   :show-inheritance:
