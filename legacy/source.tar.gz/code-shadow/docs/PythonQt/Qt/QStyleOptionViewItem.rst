``QStyleOptionViewItem``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionViewItem
   :members:
   :undoc-members:
   :show-inheritance:
