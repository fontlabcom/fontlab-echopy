``QOpenGLTimerQuery``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLTimerQuery
   :members:
   :undoc-members:
   :show-inheritance:
