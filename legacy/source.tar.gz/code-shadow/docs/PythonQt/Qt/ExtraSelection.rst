``ExtraSelection``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: ExtraSelection
   :members:
   :undoc-members:
   :show-inheritance:
