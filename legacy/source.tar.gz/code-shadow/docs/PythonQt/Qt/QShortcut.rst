``QShortcut``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QShortcut
   :members:
   :undoc-members:
   :show-inheritance:
