``QGesture``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGesture
   :members:
   :undoc-members:
   :show-inheritance:
