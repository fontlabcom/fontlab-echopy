``QGraphicsSceneMouseEvent``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneMouseEvent
   :members:
   :undoc-members:
   :show-inheritance:
