``QGestureEvent``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGestureEvent
   :members:
   :undoc-members:
   :show-inheritance:
