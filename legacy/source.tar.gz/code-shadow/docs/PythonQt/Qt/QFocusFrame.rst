``QFocusFrame``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFocusFrame
   :members:
   :undoc-members:
   :show-inheritance:
