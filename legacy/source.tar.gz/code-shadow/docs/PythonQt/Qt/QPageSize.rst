``QPageSize``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPageSize
   :members:
   :undoc-members:
   :show-inheritance:
