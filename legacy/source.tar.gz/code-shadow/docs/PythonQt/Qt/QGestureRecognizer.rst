``QGestureRecognizer``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGestureRecognizer
   :members:
   :undoc-members:
   :show-inheritance:
