``QStatusBar``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStatusBar
   :members:
   :undoc-members:
   :show-inheritance:
