``QDir``
========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDir
   :members:
   :undoc-members:
   :show-inheritance:
