``QFocusEvent``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFocusEvent
   :members:
   :undoc-members:
   :show-inheritance:
