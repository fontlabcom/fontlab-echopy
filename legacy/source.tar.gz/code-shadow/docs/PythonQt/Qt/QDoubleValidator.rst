``QDoubleValidator``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDoubleValidator
   :members:
   :undoc-members:
   :show-inheritance:
