``QNativeGestureEvent``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QNativeGestureEvent
   :members:
   :undoc-members:
   :show-inheritance:
