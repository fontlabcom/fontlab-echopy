``QSslError``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSslError
   :members:
   :undoc-members:
   :show-inheritance:
