``QDeferredDeleteEvent``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDeferredDeleteEvent
   :members:
   :undoc-members:
   :show-inheritance:
