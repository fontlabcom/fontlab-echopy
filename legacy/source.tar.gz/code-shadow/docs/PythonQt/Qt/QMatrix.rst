``QMatrix``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMatrix
   :members:
   :undoc-members:
   :show-inheritance:
