``QSslPreSharedKeyAuthenticator``
=================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSslPreSharedKeyAuthenticator
   :members:
   :undoc-members:
   :show-inheritance:
