``QPrinterInfo``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPrinterInfo
   :members:
   :undoc-members:
   :show-inheritance:
