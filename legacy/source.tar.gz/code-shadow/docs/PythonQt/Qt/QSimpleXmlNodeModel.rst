``QSimpleXmlNodeModel``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSimpleXmlNodeModel
   :members:
   :undoc-members:
   :show-inheritance:
