``QGradient``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGradient
   :members:
   :undoc-members:
   :show-inheritance:
