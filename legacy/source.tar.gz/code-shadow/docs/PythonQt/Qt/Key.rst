``Key``
=======

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: Key
   :members:
   :undoc-members:
   :show-inheritance:
