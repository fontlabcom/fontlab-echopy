``QAction``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAction
   :members:
   :undoc-members:
   :show-inheritance:
