``QSplitter``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSplitter
   :members:
   :undoc-members:
   :show-inheritance:
