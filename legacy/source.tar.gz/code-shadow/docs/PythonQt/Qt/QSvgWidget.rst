``QSvgWidget``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSvgWidget
   :members:
   :undoc-members:
   :show-inheritance:
