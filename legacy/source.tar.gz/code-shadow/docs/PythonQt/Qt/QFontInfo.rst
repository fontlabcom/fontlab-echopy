``QFontInfo``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFontInfo
   :members:
   :undoc-members:
   :show-inheritance:
