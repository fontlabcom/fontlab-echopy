``QGraphicsBlurEffect``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsBlurEffect
   :members:
   :undoc-members:
   :show-inheritance:
