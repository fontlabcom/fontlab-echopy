``QGraphicsDropShadowEffect``
=============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsDropShadowEffect
   :members:
   :undoc-members:
   :show-inheritance:
