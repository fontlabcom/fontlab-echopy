``QPatternistSDK``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPatternistSDK
   :members:
   :undoc-members:
   :show-inheritance:
