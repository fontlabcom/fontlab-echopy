``QGLShader``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLShader
   :members:
   :undoc-members:
   :show-inheritance:
