``Margins``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: Margins
   :members:
   :undoc-members:
   :show-inheritance:
