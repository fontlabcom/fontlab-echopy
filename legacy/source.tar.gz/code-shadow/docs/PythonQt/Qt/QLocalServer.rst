``QLocalServer``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLocalServer
   :members:
   :undoc-members:
   :show-inheritance:
