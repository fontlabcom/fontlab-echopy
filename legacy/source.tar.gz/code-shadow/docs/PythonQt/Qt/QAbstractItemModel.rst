``QAbstractItemModel``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractItemModel
   :members:
   :undoc-members:
   :show-inheritance:
