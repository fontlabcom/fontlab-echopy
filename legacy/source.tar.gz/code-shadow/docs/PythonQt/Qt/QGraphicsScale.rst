``QGraphicsScale``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsScale
   :members:
   :undoc-members:
   :show-inheritance:
