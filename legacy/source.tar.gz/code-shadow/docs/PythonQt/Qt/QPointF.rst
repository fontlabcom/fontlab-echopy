``QPointF``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPointF
   :members:
   :undoc-members:
   :show-inheritance:
