``QSortFilterProxyModel``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSortFilterProxyModel
   :members:
   :undoc-members:
   :show-inheritance:
