``QAbstractProxyModel``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractProxyModel
   :members:
   :undoc-members:
   :show-inheritance:
