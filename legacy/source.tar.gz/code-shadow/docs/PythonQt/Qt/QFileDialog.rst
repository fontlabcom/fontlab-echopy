``QFileDialog``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileDialog
   :members:
   :undoc-members:
   :show-inheritance:
