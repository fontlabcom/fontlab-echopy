``QBackingStore``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBackingStore
   :members:
   :undoc-members:
   :show-inheritance:
