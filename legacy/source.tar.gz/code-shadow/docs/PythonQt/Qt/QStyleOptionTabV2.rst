``QStyleOptionTabV2``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTabV2
   :members:
   :undoc-members:
   :show-inheritance:
