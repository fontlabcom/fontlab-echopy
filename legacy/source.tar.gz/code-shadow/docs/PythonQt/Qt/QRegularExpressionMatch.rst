``QRegularExpressionMatch``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegularExpressionMatch
   :members:
   :undoc-members:
   :show-inheritance:
