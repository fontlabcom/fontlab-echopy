``QPlainTextEdit``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPlainTextEdit
   :members:
   :undoc-members:
   :show-inheritance:
