``QIdentityProxyModel``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QIdentityProxyModel
   :members:
   :undoc-members:
   :show-inheritance:
