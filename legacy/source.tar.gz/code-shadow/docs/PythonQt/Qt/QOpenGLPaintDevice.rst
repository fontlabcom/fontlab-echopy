``QOpenGLPaintDevice``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLPaintDevice
   :members:
   :undoc-members:
   :show-inheritance:
