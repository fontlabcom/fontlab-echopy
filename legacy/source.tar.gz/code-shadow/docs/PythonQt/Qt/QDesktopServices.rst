``QDesktopServices``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDesktopServices
   :members:
   :undoc-members:
   :show-inheritance:
