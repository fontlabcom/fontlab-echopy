``QItemEditorCreatorBase``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QItemEditorCreatorBase
   :members:
   :undoc-members:
   :show-inheritance:
