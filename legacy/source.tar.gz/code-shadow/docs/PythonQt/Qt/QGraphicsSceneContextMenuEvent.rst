``QGraphicsSceneContextMenuEvent``
==================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneContextMenuEvent
   :members:
   :undoc-members:
   :show-inheritance:
