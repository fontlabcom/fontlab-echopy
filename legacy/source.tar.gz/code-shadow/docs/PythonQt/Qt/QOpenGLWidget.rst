``QOpenGLWidget``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLWidget
   :members:
   :undoc-members:
   :show-inheritance:
