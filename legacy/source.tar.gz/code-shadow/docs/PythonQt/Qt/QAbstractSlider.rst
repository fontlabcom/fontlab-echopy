``QAbstractSlider``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractSlider
   :members:
   :undoc-members:
   :show-inheritance:
