``QCollatorSortKey``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCollatorSortKey
   :members:
   :undoc-members:
   :show-inheritance:
