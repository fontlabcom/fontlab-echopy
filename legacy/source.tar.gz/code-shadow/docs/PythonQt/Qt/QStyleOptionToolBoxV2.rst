``QStyleOptionToolBoxV2``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionToolBoxV2
   :members:
   :undoc-members:
   :show-inheritance:
