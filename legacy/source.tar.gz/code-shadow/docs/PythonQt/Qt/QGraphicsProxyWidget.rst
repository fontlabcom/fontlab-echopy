``QGraphicsProxyWidget``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsProxyWidget
   :members:
   :undoc-members:
   :show-inheritance:
