``QStyleOptionTabWidgetFrame``
==============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTabWidgetFrame
   :members:
   :undoc-members:
   :show-inheritance:
