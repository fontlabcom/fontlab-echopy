``QDynamicPropertyChangeEvent``
===============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDynamicPropertyChangeEvent
   :members:
   :undoc-members:
   :show-inheritance:
