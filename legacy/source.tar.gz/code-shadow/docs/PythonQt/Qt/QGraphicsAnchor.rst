``QGraphicsAnchor``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsAnchor
   :members:
   :undoc-members:
   :show-inheritance:
