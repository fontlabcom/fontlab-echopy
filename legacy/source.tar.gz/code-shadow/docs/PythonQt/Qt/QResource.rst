``QResource``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QResource
   :members:
   :undoc-members:
   :show-inheritance:
