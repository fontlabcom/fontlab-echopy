``QElapsedTimer``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QElapsedTimer
   :members:
   :undoc-members:
   :show-inheritance:
