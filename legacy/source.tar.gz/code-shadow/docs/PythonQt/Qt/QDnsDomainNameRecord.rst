``QDnsDomainNameRecord``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDnsDomainNameRecord
   :members:
   :undoc-members:
   :show-inheritance:
