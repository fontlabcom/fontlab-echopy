``QParallelAnimationGroup``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QParallelAnimationGroup
   :members:
   :undoc-members:
   :show-inheritance:
