``QMdiSubWindow``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMdiSubWindow
   :members:
   :undoc-members:
   :show-inheritance:
