``QLocale``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLocale
   :members:
   :undoc-members:
   :show-inheritance:
