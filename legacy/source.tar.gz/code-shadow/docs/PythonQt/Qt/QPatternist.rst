``QPatternist``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPatternist
   :members:
   :undoc-members:
   :show-inheritance:
