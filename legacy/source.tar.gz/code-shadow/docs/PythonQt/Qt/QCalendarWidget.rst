``QCalendarWidget``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCalendarWidget
   :members:
   :undoc-members:
   :show-inheritance:
