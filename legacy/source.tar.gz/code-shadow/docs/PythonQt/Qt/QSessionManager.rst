``QSessionManager``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSessionManager
   :members:
   :undoc-members:
   :show-inheritance:
