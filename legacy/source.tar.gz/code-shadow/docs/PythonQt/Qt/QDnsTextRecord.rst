``QDnsTextRecord``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDnsTextRecord
   :members:
   :undoc-members:
   :show-inheritance:
