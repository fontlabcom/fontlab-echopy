``QBitmap``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBitmap
   :members:
   :undoc-members:
   :show-inheritance:
