``QMouseEventTransition``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMouseEventTransition
   :members:
   :undoc-members:
   :show-inheritance:
