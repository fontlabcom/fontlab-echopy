``QNetworkProxyQuery``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QNetworkProxyQuery
   :members:
   :undoc-members:
   :show-inheritance:
