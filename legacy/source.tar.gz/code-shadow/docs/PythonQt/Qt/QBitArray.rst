``QBitArray``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBitArray
   :members:
   :undoc-members:
   :show-inheritance:
