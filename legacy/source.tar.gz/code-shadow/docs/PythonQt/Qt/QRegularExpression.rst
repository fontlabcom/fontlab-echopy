``QRegularExpression``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegularExpression
   :members:
   :undoc-members:
   :show-inheritance:
