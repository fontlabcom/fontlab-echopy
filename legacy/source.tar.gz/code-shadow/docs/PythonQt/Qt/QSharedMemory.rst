``QSharedMemory``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSharedMemory
   :members:
   :undoc-members:
   :show-inheritance:
