``QPaintEvent``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPaintEvent
   :members:
   :undoc-members:
   :show-inheritance:
