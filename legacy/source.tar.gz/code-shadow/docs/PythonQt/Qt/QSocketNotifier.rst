``QSocketNotifier``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSocketNotifier
   :members:
   :undoc-members:
   :show-inheritance:
