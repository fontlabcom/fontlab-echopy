``QActionGroup``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QActionGroup
   :members:
   :undoc-members:
   :show-inheritance:
