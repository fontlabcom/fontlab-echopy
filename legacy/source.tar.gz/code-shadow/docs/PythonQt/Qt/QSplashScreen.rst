``QSplashScreen``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSplashScreen
   :members:
   :undoc-members:
   :show-inheritance:
