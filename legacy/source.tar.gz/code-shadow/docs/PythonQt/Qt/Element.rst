``Element``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: Element
   :members:
   :undoc-members:
   :show-inheritance:
