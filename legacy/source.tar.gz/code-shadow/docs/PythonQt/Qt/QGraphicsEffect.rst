``QGraphicsEffect``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsEffect
   :members:
   :undoc-members:
   :show-inheritance:
