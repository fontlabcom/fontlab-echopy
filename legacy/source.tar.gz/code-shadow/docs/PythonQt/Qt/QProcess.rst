``QProcess``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QProcess
   :members:
   :undoc-members:
   :show-inheritance:
