``QCommonStyle``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCommonStyle
   :members:
   :undoc-members:
   :show-inheritance:
