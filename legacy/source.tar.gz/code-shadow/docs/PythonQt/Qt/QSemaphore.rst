``QSemaphore``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSemaphore
   :members:
   :undoc-members:
   :show-inheritance:
