``QResizeEvent``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QResizeEvent
   :members:
   :undoc-members:
   :show-inheritance:
