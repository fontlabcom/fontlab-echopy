``QTabBar``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QTabBar
   :members:
   :undoc-members:
   :show-inheritance:
