``QPropertyAnimation``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPropertyAnimation
   :members:
   :undoc-members:
   :show-inheritance:
