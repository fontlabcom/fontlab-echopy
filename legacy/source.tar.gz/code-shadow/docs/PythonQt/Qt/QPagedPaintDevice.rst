``QPagedPaintDevice``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPagedPaintDevice
   :members:
   :undoc-members:
   :show-inheritance:
