``QItemDelegate``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QItemDelegate
   :members:
   :undoc-members:
   :show-inheritance:
