``QDoubleSpinBox``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDoubleSpinBox
   :members:
   :undoc-members:
   :show-inheritance:
