``QDockWidget``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDockWidget
   :members:
   :undoc-members:
   :show-inheritance:
