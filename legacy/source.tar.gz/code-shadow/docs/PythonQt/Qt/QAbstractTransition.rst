``QAbstractTransition``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractTransition
   :members:
   :undoc-members:
   :show-inheritance:
