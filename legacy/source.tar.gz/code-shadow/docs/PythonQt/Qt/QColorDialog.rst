``QColorDialog``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QColorDialog
   :members:
   :undoc-members:
   :show-inheritance:
