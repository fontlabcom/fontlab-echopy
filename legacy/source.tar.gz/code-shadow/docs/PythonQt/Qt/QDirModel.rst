``QDirModel``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDirModel
   :members:
   :undoc-members:
   :show-inheritance:
