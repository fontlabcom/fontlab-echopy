``QRadialGradient``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRadialGradient
   :members:
   :undoc-members:
   :show-inheritance:
