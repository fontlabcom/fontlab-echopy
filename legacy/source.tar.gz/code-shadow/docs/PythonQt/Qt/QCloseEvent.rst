``QCloseEvent``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCloseEvent
   :members:
   :undoc-members:
   :show-inheritance:
