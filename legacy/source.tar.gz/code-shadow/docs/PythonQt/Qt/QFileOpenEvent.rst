``QFileOpenEvent``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileOpenEvent
   :members:
   :undoc-members:
   :show-inheritance:
