``QStorageInfo``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStorageInfo
   :members:
   :undoc-members:
   :show-inheritance:
