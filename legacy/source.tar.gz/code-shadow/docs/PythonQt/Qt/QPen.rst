``QPen``
========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPen
   :members:
   :undoc-members:
   :show-inheritance:
