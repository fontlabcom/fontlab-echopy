``QPersistentModelIndex``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPersistentModelIndex
   :members:
   :undoc-members:
   :show-inheritance:
