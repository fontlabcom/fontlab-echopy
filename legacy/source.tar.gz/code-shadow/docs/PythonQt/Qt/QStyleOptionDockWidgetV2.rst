``QStyleOptionDockWidgetV2``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionDockWidgetV2
   :members:
   :undoc-members:
   :show-inheritance:
