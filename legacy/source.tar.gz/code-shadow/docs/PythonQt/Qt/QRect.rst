``QRect``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRect
   :members:
   :undoc-members:
   :show-inheritance:
