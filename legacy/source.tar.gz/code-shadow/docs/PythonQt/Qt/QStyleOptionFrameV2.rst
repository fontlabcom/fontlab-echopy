``QStyleOptionFrameV2``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionFrameV2
   :members:
   :undoc-members:
   :show-inheritance:
