``QGraphicsWidget``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsWidget
   :members:
   :undoc-members:
   :show-inheritance:
