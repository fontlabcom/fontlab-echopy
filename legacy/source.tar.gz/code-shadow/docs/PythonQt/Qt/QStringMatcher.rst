``QStringMatcher``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStringMatcher
   :members:
   :undoc-members:
   :show-inheritance:
