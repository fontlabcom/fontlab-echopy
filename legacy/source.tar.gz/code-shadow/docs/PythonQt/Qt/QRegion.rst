``QRegion``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegion
   :members:
   :undoc-members:
   :show-inheritance:
