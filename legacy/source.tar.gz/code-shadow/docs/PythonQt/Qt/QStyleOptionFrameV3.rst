``QStyleOptionFrameV3``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionFrameV3
   :members:
   :undoc-members:
   :show-inheritance:
