``QRgba64``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRgba64
   :members:
   :undoc-members:
   :show-inheritance:
