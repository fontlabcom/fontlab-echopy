``FormatRange``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: FormatRange
   :members:
   :undoc-members:
   :show-inheritance:
