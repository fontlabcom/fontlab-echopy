``QTabWidget``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QTabWidget
   :members:
   :undoc-members:
   :show-inheritance:
