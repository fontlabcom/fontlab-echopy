``QCollator``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QCollator
   :members:
   :undoc-members:
   :show-inheritance:
