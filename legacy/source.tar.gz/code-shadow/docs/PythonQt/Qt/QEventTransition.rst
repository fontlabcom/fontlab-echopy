``QEventTransition``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QEventTransition
   :members:
   :undoc-members:
   :show-inheritance:
