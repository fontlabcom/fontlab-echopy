``QGLFormat``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLFormat
   :members:
   :undoc-members:
   :show-inheritance:
