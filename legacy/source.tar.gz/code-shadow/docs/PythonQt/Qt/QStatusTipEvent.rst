``QStatusTipEvent``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStatusTipEvent
   :members:
   :undoc-members:
   :show-inheritance:
