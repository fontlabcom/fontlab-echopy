``QMenuBar``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMenuBar
   :members:
   :undoc-members:
   :show-inheritance:
