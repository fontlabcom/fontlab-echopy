``QFileSystemWatcher``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileSystemWatcher
   :members:
   :undoc-members:
   :show-inheritance:
