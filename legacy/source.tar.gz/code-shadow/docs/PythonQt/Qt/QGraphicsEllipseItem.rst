``QGraphicsEllipseItem``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsEllipseItem
   :members:
   :undoc-members:
   :show-inheritance:
