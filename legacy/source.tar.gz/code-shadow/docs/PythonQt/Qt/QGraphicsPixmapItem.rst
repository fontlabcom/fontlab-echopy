``QGraphicsPixmapItem``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsPixmapItem
   :members:
   :undoc-members:
   :show-inheritance:
