``QGraphicsLineItem``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsLineItem
   :members:
   :undoc-members:
   :show-inheritance:
