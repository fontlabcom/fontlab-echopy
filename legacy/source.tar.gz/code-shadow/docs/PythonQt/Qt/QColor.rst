``QColor``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QColor
   :members:
   :undoc-members:
   :show-inheritance:
