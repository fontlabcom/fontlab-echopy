``QTableWidgetSelectionRange``
==============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QTableWidgetSelectionRange
   :members:
   :undoc-members:
   :show-inheritance:
