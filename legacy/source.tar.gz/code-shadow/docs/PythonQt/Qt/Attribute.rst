``Attribute``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: Attribute
   :members:
   :undoc-members:
   :show-inheritance:
