``QSslCertificateExtension``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSslCertificateExtension
   :members:
   :undoc-members:
   :show-inheritance:
