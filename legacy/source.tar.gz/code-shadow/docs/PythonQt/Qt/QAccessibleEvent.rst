``QAccessibleEvent``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAccessibleEvent
   :members:
   :undoc-members:
   :show-inheritance:
