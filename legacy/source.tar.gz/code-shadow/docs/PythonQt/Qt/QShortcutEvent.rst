``QShortcutEvent``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QShortcutEvent
   :members:
   :undoc-members:
   :show-inheritance:
