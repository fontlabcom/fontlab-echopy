``QAbstractAnimation``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractAnimation
   :members:
   :undoc-members:
   :show-inheritance:
