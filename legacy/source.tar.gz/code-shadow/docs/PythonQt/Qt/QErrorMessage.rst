``QErrorMessage``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QErrorMessage
   :members:
   :undoc-members:
   :show-inheritance:
