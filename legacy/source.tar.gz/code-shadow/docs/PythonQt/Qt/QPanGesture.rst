``QPanGesture``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPanGesture
   :members:
   :undoc-members:
   :show-inheritance:
