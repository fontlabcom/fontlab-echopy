``QFileInfo``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileInfo
   :members:
   :undoc-members:
   :show-inheritance:
