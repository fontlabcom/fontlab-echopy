``QFontMetricsF``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFontMetricsF
   :members:
   :undoc-members:
   :show-inheritance:
