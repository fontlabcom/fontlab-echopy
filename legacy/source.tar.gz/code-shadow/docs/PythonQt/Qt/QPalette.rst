``QPalette``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPalette
   :members:
   :undoc-members:
   :show-inheritance:
