``QSystemSemaphore``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSystemSemaphore
   :members:
   :undoc-members:
   :show-inheritance:
