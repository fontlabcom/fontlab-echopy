``QLinearGradient``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLinearGradient
   :members:
   :undoc-members:
   :show-inheritance:
