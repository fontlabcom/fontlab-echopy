``QDnsMailExchangeRecord``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDnsMailExchangeRecord
   :members:
   :undoc-members:
   :show-inheritance:
