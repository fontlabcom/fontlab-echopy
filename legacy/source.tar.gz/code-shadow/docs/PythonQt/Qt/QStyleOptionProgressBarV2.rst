``QStyleOptionProgressBarV2``
=============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionProgressBarV2
   :members:
   :undoc-members:
   :show-inheritance:
