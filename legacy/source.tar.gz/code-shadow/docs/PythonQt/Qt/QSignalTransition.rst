``QSignalTransition``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSignalTransition
   :members:
   :undoc-members:
   :show-inheritance:
