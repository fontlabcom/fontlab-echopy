``QItemSelection``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QItemSelection
   :members:
   :undoc-members:
   :show-inheritance:
