``QLCDNumber``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLCDNumber
   :members:
   :undoc-members:
   :show-inheritance:
