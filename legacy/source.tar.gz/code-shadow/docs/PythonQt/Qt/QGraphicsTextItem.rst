``QGraphicsTextItem``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsTextItem
   :members:
   :undoc-members:
   :show-inheritance:
