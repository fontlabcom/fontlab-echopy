``QAnimationGroup``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAnimationGroup
   :members:
   :undoc-members:
   :show-inheritance:
