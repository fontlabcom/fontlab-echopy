``QSplitterHandle``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSplitterHandle
   :members:
   :undoc-members:
   :show-inheritance:
