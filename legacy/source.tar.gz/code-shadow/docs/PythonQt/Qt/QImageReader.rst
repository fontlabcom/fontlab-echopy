``QImageReader``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QImageReader
   :members:
   :undoc-members:
   :show-inheritance:
