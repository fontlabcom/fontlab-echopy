``QMetaClassInfo``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMetaClassInfo
   :members:
   :undoc-members:
   :show-inheritance:
