``QChildEvent``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QChildEvent
   :members:
   :undoc-members:
   :show-inheritance:
