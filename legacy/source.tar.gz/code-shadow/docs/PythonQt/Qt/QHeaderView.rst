``QHeaderView``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QHeaderView
   :members:
   :undoc-members:
   :show-inheritance:
