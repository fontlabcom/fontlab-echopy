``QBuffer``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBuffer
   :members:
   :undoc-members:
   :show-inheritance:
