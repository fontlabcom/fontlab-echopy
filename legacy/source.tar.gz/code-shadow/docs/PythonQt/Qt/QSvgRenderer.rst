``QSvgRenderer``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSvgRenderer
   :members:
   :undoc-members:
   :show-inheritance:
