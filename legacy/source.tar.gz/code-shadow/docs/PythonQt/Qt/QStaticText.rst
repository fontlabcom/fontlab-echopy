``QStaticText``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStaticText
   :members:
   :undoc-members:
   :show-inheritance:
