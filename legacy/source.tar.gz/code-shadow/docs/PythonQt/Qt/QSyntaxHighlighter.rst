``QSyntaxHighlighter``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSyntaxHighlighter
   :members:
   :undoc-members:
   :show-inheritance:
