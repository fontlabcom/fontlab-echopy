``QSize``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSize
   :members:
   :undoc-members:
   :show-inheritance:
