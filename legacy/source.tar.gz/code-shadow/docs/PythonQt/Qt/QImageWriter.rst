``QImageWriter``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QImageWriter
   :members:
   :undoc-members:
   :show-inheritance:
