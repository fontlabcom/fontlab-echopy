``QStackedLayout``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStackedLayout
   :members:
   :undoc-members:
   :show-inheritance:
