``QStyleOptionToolBar``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionToolBar
   :members:
   :undoc-members:
   :show-inheritance:
