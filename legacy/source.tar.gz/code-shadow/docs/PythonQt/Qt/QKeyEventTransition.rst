``QKeyEventTransition``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QKeyEventTransition
   :members:
   :undoc-members:
   :show-inheritance:
