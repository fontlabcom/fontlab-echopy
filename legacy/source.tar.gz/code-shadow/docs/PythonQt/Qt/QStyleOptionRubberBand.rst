``QStyleOptionRubberBand``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionRubberBand
   :members:
   :undoc-members:
   :show-inheritance:
