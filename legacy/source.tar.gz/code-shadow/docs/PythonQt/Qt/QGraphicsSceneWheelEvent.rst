``QGraphicsSceneWheelEvent``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneWheelEvent
   :members:
   :undoc-members:
   :show-inheritance:
