``QSysInfo``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSysInfo
   :members:
   :undoc-members:
   :show-inheritance:
