``QStyleOptionToolBox``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionToolBox
   :members:
   :undoc-members:
   :show-inheritance:
