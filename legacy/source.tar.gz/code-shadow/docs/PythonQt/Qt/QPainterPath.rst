``QPainterPath``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPainterPath
   :members:
   :undoc-members:
   :show-inheritance:
