``QGraphicsScene``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsScene
   :members:
   :undoc-members:
   :show-inheritance:
