``QGraphicsItemGroup``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsItemGroup
   :members:
   :undoc-members:
   :show-inheritance:
