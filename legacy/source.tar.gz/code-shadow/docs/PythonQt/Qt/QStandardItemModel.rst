``QStandardItemModel``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStandardItemModel
   :members:
   :undoc-members:
   :show-inheritance:
