``QConicalGradient``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QConicalGradient
   :members:
   :undoc-members:
   :show-inheritance:
