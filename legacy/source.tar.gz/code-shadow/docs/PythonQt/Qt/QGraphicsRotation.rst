``QGraphicsRotation``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsRotation
   :members:
   :undoc-members:
   :show-inheritance:
