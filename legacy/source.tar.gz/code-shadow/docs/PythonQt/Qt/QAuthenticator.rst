``QAuthenticator``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAuthenticator
   :members:
   :undoc-members:
   :show-inheritance:
