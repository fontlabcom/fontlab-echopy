``QMarginsF``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMarginsF
   :members:
   :undoc-members:
   :show-inheritance:
