``QGroupBox``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGroupBox
   :members:
   :undoc-members:
   :show-inheritance:
