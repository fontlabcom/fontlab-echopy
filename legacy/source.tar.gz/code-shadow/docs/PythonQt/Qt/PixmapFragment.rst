``PixmapFragment``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: PixmapFragment
   :members:
   :undoc-members:
   :show-inheritance:
