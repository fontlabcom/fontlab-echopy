``QIcon``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QIcon
   :members:
   :undoc-members:
   :show-inheritance:
