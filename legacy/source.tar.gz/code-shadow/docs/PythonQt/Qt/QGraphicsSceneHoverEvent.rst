``QGraphicsSceneHoverEvent``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSceneHoverEvent
   :members:
   :undoc-members:
   :show-inheritance:
