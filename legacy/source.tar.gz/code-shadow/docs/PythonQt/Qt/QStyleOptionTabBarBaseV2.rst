``QStyleOptionTabBarBaseV2``
============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTabBarBaseV2
   :members:
   :undoc-members:
   :show-inheritance:
