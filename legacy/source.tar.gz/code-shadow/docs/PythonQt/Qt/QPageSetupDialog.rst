``QPageSetupDialog``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPageSetupDialog
   :members:
   :undoc-members:
   :show-inheritance:
