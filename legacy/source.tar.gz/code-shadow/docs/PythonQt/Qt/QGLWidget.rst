``QGLWidget``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLWidget
   :members:
   :undoc-members:
   :show-inheritance:
