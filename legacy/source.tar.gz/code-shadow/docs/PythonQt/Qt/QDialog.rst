``QDialog``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDialog
   :members:
   :undoc-members:
   :show-inheritance:
