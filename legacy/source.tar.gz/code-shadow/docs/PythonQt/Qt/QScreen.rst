``QScreen``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QScreen
   :members:
   :undoc-members:
   :show-inheritance:
