``QNetworkAddressEntry``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QNetworkAddressEntry
   :members:
   :undoc-members:
   :show-inheritance:
