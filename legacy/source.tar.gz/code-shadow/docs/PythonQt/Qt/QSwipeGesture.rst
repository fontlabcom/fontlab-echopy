``QSwipeGesture``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSwipeGesture
   :members:
   :undoc-members:
   :show-inheritance:
