``QDialogButtonBox``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDialogButtonBox
   :members:
   :undoc-members:
   :show-inheritance:
