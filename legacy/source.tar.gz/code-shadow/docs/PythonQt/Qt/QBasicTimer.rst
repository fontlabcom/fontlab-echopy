``QBasicTimer``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBasicTimer
   :members:
   :undoc-members:
   :show-inheritance:
