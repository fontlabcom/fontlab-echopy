``QAbstractXmlReceiver``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractXmlReceiver
   :members:
   :undoc-members:
   :show-inheritance:
