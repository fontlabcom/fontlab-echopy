``QGraphicsItem``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsItem
   :members:
   :undoc-members:
   :show-inheritance:
