``QAbstractUriResolver``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractUriResolver
   :members:
   :undoc-members:
   :show-inheritance:
