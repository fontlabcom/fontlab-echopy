``QGraphicsSvgItem``
====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSvgItem
   :members:
   :undoc-members:
   :show-inheritance:
