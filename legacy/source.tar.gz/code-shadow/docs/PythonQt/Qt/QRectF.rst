``QRectF``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRectF
   :members:
   :undoc-members:
   :show-inheritance:
