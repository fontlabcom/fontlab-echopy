``QSizeF``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSizeF
   :members:
   :undoc-members:
   :show-inheritance:
