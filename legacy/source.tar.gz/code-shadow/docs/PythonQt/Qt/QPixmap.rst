``QPixmap``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPixmap
   :members:
   :undoc-members:
   :show-inheritance:
