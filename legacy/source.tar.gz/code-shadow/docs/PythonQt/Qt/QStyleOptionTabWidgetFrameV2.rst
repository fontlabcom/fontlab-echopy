``QStyleOptionTabWidgetFrameV2``
================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTabWidgetFrameV2
   :members:
   :undoc-members:
   :show-inheritance:
