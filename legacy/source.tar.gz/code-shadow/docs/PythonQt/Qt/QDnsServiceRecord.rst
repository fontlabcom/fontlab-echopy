``QDnsServiceRecord``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDnsServiceRecord
   :members:
   :undoc-members:
   :show-inheritance:
