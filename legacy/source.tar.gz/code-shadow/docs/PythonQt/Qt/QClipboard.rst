``QClipboard``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QClipboard
   :members:
   :undoc-members:
   :show-inheritance:
