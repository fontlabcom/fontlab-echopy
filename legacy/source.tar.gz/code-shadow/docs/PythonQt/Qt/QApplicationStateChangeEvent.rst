``QApplicationStateChangeEvent``
================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QApplicationStateChangeEvent
   :members:
   :undoc-members:
   :show-inheritance:
