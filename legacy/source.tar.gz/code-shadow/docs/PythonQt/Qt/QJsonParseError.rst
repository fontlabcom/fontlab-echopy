``QJsonParseError``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QJsonParseError
   :members:
   :undoc-members:
   :show-inheritance:
