``QPrintPreviewWidget``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPrintPreviewWidget
   :members:
   :undoc-members:
   :show-inheritance:
