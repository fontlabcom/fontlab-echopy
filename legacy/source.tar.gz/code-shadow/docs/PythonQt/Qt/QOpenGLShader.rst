``QOpenGLShader``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QOpenGLShader
   :members:
   :undoc-members:
   :show-inheritance:
