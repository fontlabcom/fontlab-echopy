``QPlatformSurfaceEvent``
=========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPlatformSurfaceEvent
   :members:
   :undoc-members:
   :show-inheritance:
