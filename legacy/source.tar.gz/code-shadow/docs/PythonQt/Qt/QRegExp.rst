``QRegExp``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRegExp
   :members:
   :undoc-members:
   :show-inheritance:
