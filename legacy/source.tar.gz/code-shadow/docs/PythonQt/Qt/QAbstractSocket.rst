``QAbstractSocket``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractSocket
   :members:
   :undoc-members:
   :show-inheritance:
