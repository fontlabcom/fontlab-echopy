``QSlider``
===========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSlider
   :members:
   :undoc-members:
   :show-inheritance:
