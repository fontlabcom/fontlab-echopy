``QLine``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLine
   :members:
   :undoc-members:
   :show-inheritance:
