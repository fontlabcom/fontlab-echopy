``QDirIterator``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDirIterator
   :members:
   :undoc-members:
   :show-inheritance:
