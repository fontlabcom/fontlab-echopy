``QScrollerProperties``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QScrollerProperties
   :members:
   :undoc-members:
   :show-inheritance:
