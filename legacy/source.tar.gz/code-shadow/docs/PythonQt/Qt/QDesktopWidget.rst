``QDesktopWidget``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDesktopWidget
   :members:
   :undoc-members:
   :show-inheritance:
