``QDragLeaveEvent``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDragLeaveEvent
   :members:
   :undoc-members:
   :show-inheritance:
