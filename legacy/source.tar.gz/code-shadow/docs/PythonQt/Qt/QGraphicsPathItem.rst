``QGraphicsPathItem``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsPathItem
   :members:
   :undoc-members:
   :show-inheritance:
