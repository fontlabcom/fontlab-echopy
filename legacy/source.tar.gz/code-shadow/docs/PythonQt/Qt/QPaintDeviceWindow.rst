``QPaintDeviceWindow``
======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPaintDeviceWindow
   :members:
   :undoc-members:
   :show-inheritance:
