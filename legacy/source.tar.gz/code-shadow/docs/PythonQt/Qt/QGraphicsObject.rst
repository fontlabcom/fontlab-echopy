``QGraphicsObject``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsObject
   :members:
   :undoc-members:
   :show-inheritance:
