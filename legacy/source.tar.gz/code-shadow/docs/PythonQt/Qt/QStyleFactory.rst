``QStyleFactory``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleFactory
   :members:
   :undoc-members:
   :show-inheritance:
