``QGLColormap``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGLColormap
   :members:
   :undoc-members:
   :show-inheritance:
