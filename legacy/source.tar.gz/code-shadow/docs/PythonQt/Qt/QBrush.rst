``QBrush``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QBrush
   :members:
   :undoc-members:
   :show-inheritance:
