``QDropEvent``
==============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDropEvent
   :members:
   :undoc-members:
   :show-inheritance:
