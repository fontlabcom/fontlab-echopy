``QSvgGenerator``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSvgGenerator
   :members:
   :undoc-members:
   :show-inheritance:
