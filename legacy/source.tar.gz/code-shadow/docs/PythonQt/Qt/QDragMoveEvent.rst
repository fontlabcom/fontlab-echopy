``QDragMoveEvent``
==================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDragMoveEvent
   :members:
   :undoc-members:
   :show-inheritance:
