``QPicture``
============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QPicture
   :members:
   :undoc-members:
   :show-inheritance:
