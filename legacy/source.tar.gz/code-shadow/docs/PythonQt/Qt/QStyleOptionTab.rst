``QStyleOptionTab``
===================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTab
   :members:
   :undoc-members:
   :show-inheritance:
