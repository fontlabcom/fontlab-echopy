``QSignalMapper``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSignalMapper
   :members:
   :undoc-members:
   :show-inheritance:
