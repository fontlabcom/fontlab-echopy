``QMimeDatabase``
=================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMimeDatabase
   :members:
   :undoc-members:
   :show-inheritance:
