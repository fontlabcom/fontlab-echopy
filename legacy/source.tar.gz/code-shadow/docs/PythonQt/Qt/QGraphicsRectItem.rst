``QGraphicsRectItem``
=====================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsRectItem
   :members:
   :undoc-members:
   :show-inheritance:
