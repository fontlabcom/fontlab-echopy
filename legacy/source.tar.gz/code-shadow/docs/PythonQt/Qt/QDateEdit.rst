``QDateEdit``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QDateEdit
   :members:
   :undoc-members:
   :show-inheritance:
