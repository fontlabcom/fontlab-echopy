``QMessageAuthenticationCode``
==============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMessageAuthenticationCode
   :members:
   :undoc-members:
   :show-inheritance:
