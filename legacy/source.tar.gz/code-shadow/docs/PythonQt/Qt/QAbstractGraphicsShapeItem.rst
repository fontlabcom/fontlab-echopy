``QAbstractGraphicsShapeItem``
==============================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QAbstractGraphicsShapeItem
   :members:
   :undoc-members:
   :show-inheritance:
