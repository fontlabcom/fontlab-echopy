``QScreenOrientationChangeEvent``
=================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QScreenOrientationChangeEvent
   :members:
   :undoc-members:
   :show-inheritance:
