``QItemSelectionModel``
=======================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QItemSelectionModel
   :members:
   :undoc-members:
   :show-inheritance:
