``QFormLayout``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFormLayout
   :members:
   :undoc-members:
   :show-inheritance:
