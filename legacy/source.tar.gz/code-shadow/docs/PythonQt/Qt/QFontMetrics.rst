``QFontMetrics``
================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFontMetrics
   :members:
   :undoc-members:
   :show-inheritance:
