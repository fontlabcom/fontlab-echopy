``QLockFile``
=============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QLockFile
   :members:
   :undoc-members:
   :show-inheritance:
