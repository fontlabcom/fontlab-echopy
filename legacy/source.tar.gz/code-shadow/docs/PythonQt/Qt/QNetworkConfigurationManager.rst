``QNetworkConfigurationManager``
================================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QNetworkConfigurationManager
   :members:
   :undoc-members:
   :show-inheritance:
