``QStyleOptionTitleBar``
========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTitleBar
   :members:
   :undoc-members:
   :show-inheritance:
