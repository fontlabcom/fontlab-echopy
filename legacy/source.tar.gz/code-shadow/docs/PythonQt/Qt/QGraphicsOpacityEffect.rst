``QGraphicsOpacityEffect``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsOpacityEffect
   :members:
   :undoc-members:
   :show-inheritance:
