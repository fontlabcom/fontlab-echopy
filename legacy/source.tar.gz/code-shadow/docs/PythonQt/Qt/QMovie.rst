``QMovie``
==========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QMovie
   :members:
   :undoc-members:
   :show-inheritance:
