``QSpacerItem``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QSpacerItem
   :members:
   :undoc-members:
   :show-inheritance:
