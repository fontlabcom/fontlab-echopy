``QStyleOptionTabBarBase``
==========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QStyleOptionTabBarBase
   :members:
   :undoc-members:
   :show-inheritance:
