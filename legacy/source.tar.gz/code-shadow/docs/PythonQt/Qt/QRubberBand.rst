``QRubberBand``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QRubberBand
   :members:
   :undoc-members:
   :show-inheritance:
