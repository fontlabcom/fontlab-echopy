``QFileDevice``
===============

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFileDevice
   :members:
   :undoc-members:
   :show-inheritance:
