``QFile``
=========

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QFile
   :members:
   :undoc-members:
   :show-inheritance:
