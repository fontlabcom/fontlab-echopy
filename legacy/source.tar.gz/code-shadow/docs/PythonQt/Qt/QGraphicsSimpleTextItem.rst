``QGraphicsSimpleTextItem``
===========================

.. currentmodule:: flproxy.PythonQt.Qt

.. autoclass:: QGraphicsSimpleTextItem
   :members:
   :undoc-members:
   :show-inheritance:
