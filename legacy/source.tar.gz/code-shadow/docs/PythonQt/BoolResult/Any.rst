``Any``
=======

.. currentmodule:: flproxy.PythonQt.BoolResult

.. autoclass:: Any
   :members:
   :undoc-members:
   :show-inheritance:
