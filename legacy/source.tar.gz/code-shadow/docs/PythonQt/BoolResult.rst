``flproxy.PythonQt.BoolResult``
===============================

.. automodule:: flproxy.PythonQt.BoolResult
   :no-members:

Classes
-------

.. toctree::
   :maxdepth: 1

   BoolResult/Any
